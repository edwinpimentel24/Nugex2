package com.infy.model;

public class ResultOutput {

    private String nuggets;
    private String combo;
    private String change;

    public String getNuggets() {
        return nuggets;
    }

    public void setNuggets(String nuggets) {
        this.nuggets = nuggets;
    }

    public String getCombo() {
        return combo;
    }

    public void setCombo(String combo) {
        this.combo = combo;
    }

    public String getChange() {
        return change;
    }

    public void setChange(String change) {
        this.change = change;
    }
}
